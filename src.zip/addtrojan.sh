#!/bin/bash

# Fetch URL from the first argument
data_acc="https://zds.web.id/api/exp?key="
data_key=$(cat /root/.key)

status_code=$(curl -s -o /dev/null -w "%{http_code}" $data_acc$data_key)

if [ $status_code -eq 200 ]; then
    expiry_date=$(date -d "$(curl -s $data_acc$data_key)" +%s)
    current_date=$(date +%s)
    remaining_days=$(( (expiry_date - current_date) / 86400 ))

    if [ $expiry_date -gt $current_date ]; then

    

# Colors
red="\e[91m"
green="\e[92m"
yellow="\e[93m"
blue="\e[94m"
purple="\e[95m"
cyan="\e[96m"
white="\e[97m"
reset="\e[0m"
orange="\e[38;5;208m"

# Function to print rainbow text
print_rainbow() {
    local text="$1"
    local length=${#text}
    local start_color=(255 255 0) # yellow
    local mid_color=(0 255 0)     # green
    local end_color=(255 255 0)   # yellow

    for ((i = 0; i < length; i++)); do
        local progress=$((i * 100 / (length - 1)))

        if [ $progress -lt 50 ]; then
            local factor=$((progress * 2))
            r=$((start_color[0] * (100 - factor) / 100 + mid_color[0] * factor / 100))
            g=$((start_color[1] * (100 - factor) / 100 + mid_color[1] * factor / 100))
            b=$((start_color[2] * (100 - factor) / 100 + mid_color[2] * factor / 100))
        else
            local factor=$(((progress - 50) * 2))
            r=$((mid_color[0] * (100 - factor) / 100 + end_color[0] * factor / 100))
            g=$((mid_color[1] * (100 - factor) / 100 + end_color[1] * factor / 100))
            b=$((mid_color[2] * (100 - factor) / 100 + end_color[2] * factor / 100))
        fi

        printf "\e[38;2;%d;%d;%dm%s" "$r" "$g" "$b" "${text:$i:1}"
    done
    echo -e "$reset"
}
# Variables
ip=$(wget -qO- ipv4.icanhazip.com)
srv_date=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date=$(date +"%Y-%m-%d" -d "$srv_date")
ip_url="https://ipinfo.io/ip"
city=$(cat /etc/xray/city 2>/dev/null || echo "Unknown city")
pubkey=$(cat /etc/slowdns/server.pub 2>/dev/null || echo "Pubkey not available")
ns_domain=$(cat /etc/xray/dns 2>/dev/null || echo "NS domain not set")
domain=$(cat /etc/xray/domain 2>/dev/null || hostname -f)
uuid=$(cat /proc/sys/kernel/random/uuid)

# Exception handling for missing configuration files
if [ ! -f "/etc/xray/trojan/config.json" ]; then
    echo "Trojan configuration file not found. Creating a new file..."
    mkdir -p /etc/xray/trojan
    echo '{"inbounds": []}' > /etc/xray/trojan/config.json
fi

# Exception handling for missing directory
if [ ! -d "/etc/xray/trojan" ]; then
    echo "Directory /etc/xray/trojan not found. Creating directory..."
    mkdir -p /etc/xray/trojan
fi

# Exception handling for missing database file
if [ ! -f "/etc/xray/trojan/.trojan.db" ]; then
    echo "Trojan database file not found. Creating a new file..."
    touch /etc/xray/trojan/.trojan.db
fi

# Loading animation
echo ""
echo -ne "${yellow}Preparing Premium Account${reset}"
for i in {1..2}; do
    for j in ⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏; do
        echo -ne "\r${yellow}Preparing Premium Account $j${reset}"
        sleep 0.1
    done
done
echo -ne "\r${yellow}Premium Account Ready to be created!${reset}\n"
sleep 1
clear

# User data input
print_rainbow "┌─────────────────────────────────────────┐"
print_rainbow "│            ENTER USER DATA              │"
print_rainbow "└─────────────────────────────────────────┘"
while true; do
    read -p "   Name: " user
    if [[ ${#user} -lt 3 || ! "$user" =~ ^[a-zA-Z0-9_-]+$ ]]; then
        printf "\033[1A\033[0J"
        echo -e "${red}   Username cannot be empty${reset}"
        continue
    fi
    if grep -q "^### $user " /etc/xray/trojan/config.json; then
        random_number=$(head /dev/urandom | tr -dc A-Za-z0-9 | head -c 5)
        user="${random_number}${user}"
        echo -e "${yellow}   Username already exists. New username used: $user${reset}"
        break
    else
        break
    fi
done
echo ""
printf "\033[10A\033[0J"
print_rainbow "┌─────────────────────────────────────────┐"
print_rainbow "│  .::.  Script by ZIDSTORE  .::.    │"
print_rainbow "│      Input xray/trojan account deps     │"
print_rainbow "│     Set Quota/IP Limit for Account      │"
print_rainbow "│            0 For Unlimited              │"
print_rainbow "└─────────────────────────────────────────┘"
echo "   Username : $user"
until [[ $duration =~ ^[0-9]+$ ]]; do
    read -p "   Active period (days): " duration
done
until [[ $quota =~ ^[0-9]+$ ]]; do
    read -p "   User Quota (GB): " quota
done
until [[ $ip_limit =~ ^[0-9]+$ ]]; do
    read -p "   User Limit (IP): " ip_limit
done

# Account creation process
exp=$(date -d "$duration days" +"%Y-%m-%d")
sed -i '/#trojan$/a\### '"$user $exp"'\
},{"password": "'""$uuid""'","email": "'""$user""'"' /etc/xray/trojan/config.json
sed -i '/#trojangrpc$/a\### '"$user $exp"'\
},{"password": "'""$uuid""'","email": "'""$user""'"' /etc/xray/trojan/config.json

# Create configuration files
cat > /etc/xray/trojan/$user-tls.json <<EOF
{
    "v": "2",
    "ps": "$user WS (CDN) TLS",
    "add": "${domain}",
    "port": "443",
    "id": "${uuid}",
    "aid": "0",
    "net": "ws",
    "path": "/whatever/trojan-ws",
    "type": "none",
    "host": "${domain}",
    "tls": "tls"
}
EOF

cat > /etc/xray/trojan/$user-non.json <<EOF
{
    "v": "2",
    "ps": "$user WS (CDN) NTLS",
    "add": "${domain}",
    "port": "80",
    "id": "${uuid}",
    "aid": "0",
    "net": "ws",
    "path": "/whatever/trojan-ws",
    "type": "none",
    "host": "${domain}",
    "tls": "none"
}
EOF

cat > /etc/xray/trojan/$user-grpc.json <<EOF
{
    "v": "2",
    "ps": "$user (SNI) GRPC",
    "add": "${domain}",
    "port": "443",
    "id": "${uuid}",
    "aid": "0",
    "net": "grpc",
    "path": "trojan-grpc",
    "type": "none",
    "host": "${domain}",
    "tls": "tls"
}
EOF

# Create configuration file for OpenClash
cat > /var/www/html/trojan-$user.txt <<-END
---------------------
# Format Trojan WS (CDN)
---------------------

- name: Trojan-$user-WS (CDN)
  type: trojan
  server: ${domain}
  port: 443
  password: ${uuid}
  udp: true
  sni: ${domain}
  skip-cert-verify: true
  network: ws
  ws-opts:
    path: /whatever/trojan-ws
    headers:
      Host: ${domain}
---------------------
# Format Trojan WS (CDN) Non TLS
---------------------

- name: Trojan-$user-WS (CDN) Non TLS
  type: trojan
  server: ${domain}
  port: 80
  password: ${uuid}
  udp: true
  sni: ${domain}
  skip-cert-verify: false
  network: ws
  ws-opts:
    path: /whatever/trojan-ws
    headers:
      Host: ${domain}
---------------------
# Format Trojan gRPC (SNI)
---------------------

- name: Trojan-$user-gRPC (SNI)
  server: ${domain}
  port: 443
  type: trojan
  password: ${uuid}
  network: grpc
  sni: ${domain}
  skip-cert-verify: true
  grpc-opts:
    grpc-service-name: trojan-grpc

---------------------
# Trojan Account Links
---------------------
TLS Link : trojan://${uuid}@${domain}:443?path=%2Fwhatever%2Ftrojan-ws&security=tls&host=${domain}&type=ws&sni=${domain}#${user}
---------------------
GRPC Link : trojan://${uuid}@${domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni=${domain}#${user}
---------------------

END

# Generate Trojan links
trojan_tls="trojan://${uuid}@${domain}:443?path=%2Fwhatever%2Ftrojan-ws&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"
trojan_grpc="trojan://${uuid}@${domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni=${domain}#${user}"

# Restart Trojan service
if ! systemctl restart trojan@config > /dev/null 2>&1; then
    echo -e "${red}Failed to restart Trojan service. Please check system logs for more information.${reset}"
    exit 1
fi

# Exception handling for missing configuration file
if [ ! -f "/etc/xray/trojan/config.json" ]; then
    echo "Warning: Trojan configuration file not found. Creating a new file..."
    mkdir -p /etc/xray/trojan
    echo '{"inbounds": []}' > /etc/xray/trojan/config.json
    systemctl restart trojan@config
fi

# Create directory if it doesn't exist
if [ ! -d "/etc/xray/trojan" ]; then
    echo "Directory /etc/xray/trojan not found. Creating directory..."
    mkdir -p /etc/xray/trojan
    if [ $? -ne 0 ]; then
        echo "Failed to create directory /etc/xray/trojan. Make sure you have sufficient permissions."
        exit 1
    fi
fi

# Set default values if empty
[ -z ${ip_limit} ] && ip_limit="0"
[ -z ${quota} ] && quota="0"

# Convert Quota to bytes
quota_bytes=$((${quota} * 1024 * 1024 * 1024))

# Save quota and IP limit data
if [[ ${quota} != "0" ]]; then
    echo "${quota_bytes}" > /etc/xray/trojan/${user}
    echo "${ip_limit}" > /etc/xray/trojan/${user}IP
fi

# Update database
db_file="/etc/xray/trojan/.trojan.db"
temp_file="/etc/xray/trojan/.trojan.db.tmp"

# Remove old entry if exists
grep -v "^### ${user} " "$db_file" > "$temp_file"
mv "$temp_file" "$db_file"

# Add new entry
echo "### ${user} ${exp} ${uuid}" >> "$db_file"

# Display account information
clear -x
print_rainbow "───────────────────────────"
print_rainbow "    Xray/Trojan Account    "
print_rainbow "───────────────────────────"
echo -e "Description  : ${user}"
echo -e "Host Server  : ${domain}"
echo -e "Host XrayDNS : ${ns_domain}"
echo -e "Location     : ${city}"
echo -e "TLS Port     : 443"
echo -e "DNS Port     : 443, 53"
echo -e "GRPC Port    : 443"
echo -e "Security     : auto"
echo -e "Network      : WS or gRPC"
echo -e "Path         : /whatever/trojan-ws"
echo -e "ServiceName  : trojan-grpc"
echo -e "Password     : ${uuid}"
echo -e "Public Key   : ${pubkey}"
print_rainbow "───────────────────────────"
echo -e "TLS Link     : ${trojan_tls}"
print_rainbow "───────────────────────────"
echo -e "GRPC Link    : ${trojan_grpc}"
print_rainbow "───────────────────────────"
echo -e "OpenClash Format : https://${domain}:81/trojan-${user}.txt"
print_rainbow "───────────────────────────"
echo -e "Expires On   : ${exp}"
echo -e ""

# Save log
{
    echo "───────────────────────────"
    echo "    Xray/Trojan Account    "
    echo "───────────────────────────"
    echo "Description  : ${user}"
    echo "Host Server  : ${domain}"
    echo "Host XrayDNS : ${ns_domain}"
    echo "Location     : ${city}"
    echo "TLS Port     : 443"
    echo "DNS Port     : 443, 53"
    echo "GRPC Port    : 443"
    echo "Security     : auto"
    echo "Network      : WS or gRPC"
    echo "Path         : /whatever/trojan-ws"
    echo "ServiceName  : trojan-grpc"
    echo "Password     : ${uuid}"
    echo "Public Key   : ${pubkey}"
    echo "───────────────────────────"
    echo "TLS Link     : ${trojan_tls}"
    echo "───────────────────────────"
    echo "GRPC Link    : ${trojan_grpc}"
    echo "───────────────────────────"
    echo "OpenClash Format : https://${domain}:81/trojan-${user}.txt"
    echo "───────────────────────────"
    echo "Expires On   : ${exp}"
    echo ""
} >> /etc/xray/trojan/log-create-${user}.log

else
    echo -e "\e[38;5;130m────────────────────────────────────────────\033[0m"
    echo -e "\e[38;5;82m         ZIDSTORE AUTOSCRIPT          \033[0m"
    echo -e "\e[38;5;130m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            \033[31mPERMISSION DENIED !\033[0m"
    echo -e "   \033[0;33mYour VPS\033[0m $(wget -qO- ipv4.icanhazip.com) \033[0;33mHas been Banned\033[0m"
    echo -e "     \033[0;33mBuy access permissions for scripts\033[0m"
    echo -e "             \033[0;33mContact Admin :\033[0m"
    echo -e "      \033[0;32mWhatsApp\033[0m wa.me/6281584099035"
    echo -e "         \033[0;96mTelegram\033[0m t.me/storezid2"
    echo -e "\e[38;5;130m────────────────────────────────────────────\033[0m"
    exit
fi
else
    echo -e "\e[38;5;130m────────────────────────────────────────────\033[0m"
    echo -e "\e[38;5;82m         ZIDSTORE AUTOSCRIPT          \033[0m"
    echo -e "\e[38;5;130m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            \033[31mPERMISSION DENIED !\033[0m"
    echo -e "   \033[0;33mYour VPS\033[0m $(wget -qO- ipv4.icanhazip.com) \033[0;33mHas been Banned\033[0m"
    echo -e "     \033[0;33mBuy access permissions for scripts\033[0m"
    echo -e "             \033[0;33mContact Admin :\033[0m"
    echo -e "      \033[0;32mWhatsApp\033[0m wa.me/6281584099035"
    echo -e "         \033[0;96mTelegram\033[0m t.me/storezid2"
    echo -e "\e[38;5;130m────────────────────────────────────────────\033[0m"
    exit
fi
